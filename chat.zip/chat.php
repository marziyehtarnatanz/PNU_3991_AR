<?php

require_once 'db.php';
require_once 'jdf.php';
require_once 'fa_digits.php';

$query = "select * from `chat` ORDER BY `id` DESC ";
$run = $db->query($query);

while($row = $run->fetch_array()){
    ?>
    <div id="chat_data">
        <span style="color: #4d9900; float: right; margin-right: 20px;"><?= $row['name']; ?> : </span>
        <span style="color: red;margin-right: 12px;""><?= $row['message']; ?></span>
        <span style="float: left;">
        <?php
        $time = explode(" ",$row["date"]);
        $time = str_replace('-',',',$time[0]);
        $time = explode(',',$time);
        $persian_time = gregorian_to_jalali($time[0],$time[1],$time[2]);
        $persian_time = implode('/',$persian_time);

        echo "<span style='margin-left: 20px;'>".fa_digits($persian_time)."</span>";



        ?>
        </span>
    </div>
    <?php
}