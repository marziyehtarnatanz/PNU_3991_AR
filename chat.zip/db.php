<?php

$host = "localhost";
$user = "root";
$password = "";
$dbname = "chat";


$db = new mysqli($host,$user,$password,$dbname);
mysqli_set_charset($db,"utf8");
