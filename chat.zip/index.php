<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/infobox.css">
    <title>  سیستم چت آنلاین محمد</title>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="js/infobox.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>


    <script type="text/javascript">
        function ajax() {

            var req = new XMLHttpRequest();

            req.onreadystatechange = function () {
                if(req.status==200 && req.readyState==4){
                    document.getElementById('chat').innerHTML = req.responseText;
                }
            }

            req.open('GET','chat.php','true');
            req.send();

        }
        setInterval(function () {ajax()},1000);
    </script>
</head>
<body onload="ajax()">

<div class="chat_title">
    <span style="color: #3266a8">محمد</span> پیام رسان آنلاین
</div>
<div id="container">
    <div id="chat_box"  class="nicescroll-box">
        <div id="chat"  class="wrap"></div>
    </div>
    <form method="post" action="">
        <input type="text" name="name" placeholder="نام خود را وارد کنید" />
        <textarea name="message" placeholder="پیام خود را وارد کنید"></textarea>
        <input type="submit" name="submit" value="ارسال">
    </form>
</div>

<?php

if(isset($_POST['name']) && !empty($_POST['name']))
{
    require_once 'db.php';
    $name = $_POST['name'];
    $message = $_POST['message'];


    $query = "insert into `chat` (`name`,`message`) VALUES('".$name."','".$message."') ";
    $db->query($query);
    $rows = $db->affected_rows;
    if($rows==1)
    {
        ?>
        <script>
            $("body").infobox({
                type : 'sucess',
                tittle : 'موفقیت',
                message : 'پیغام شما با موفقیت ارسال شد',
                overlay     : 'true',
                effect      : 'on',
                anim        : 'slide',  /*slide,fold,bounce,,scale*/
                vposition   : 'right',
                hposition   : 'bottom',
                timeout     : '2000',
                speed : '1000',
                animatefrom :'down'

            });
        </script>

        <?php
    }else
    {

        echo "<span style='color: #f45942; font-family: Tahoma;'>مشکلی در ارسال وجود دارد</span>";
    }



}
?>

<script type="text/javascript">
    $(".nicescroll-box").niceScroll(".wrap",{cursorcolor:"green"});
    $("body").niceScroll({cursorcolor:"blue"});
</script>

</body>
</html>